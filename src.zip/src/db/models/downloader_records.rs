use sea_orm::entity::prelude::*;
use chrono::FixedOffset;
use sea_orm::sqlx::types::chrono::DateTime;

#[sea_orm::model]
#[derive(Clone, Debug, PartialEq, DeriveEntityModel)]
#[sea_orm(table_name = "downloader_records")]
pub struct Model {
    #[sea_orm(primary_key)]
    pub id: i64,
    #[sea_orm(unique, column_type = "Text")]
    pub request_id: String,
    pub channel_id: i64,
    #[sea_orm(column_type = "Text")]
    pub url: String,
    #[sea_orm(column_type = "Text")]
    pub path: String,
    #[sea_orm(column_type = "Text")]
    pub priority: String,
    pub downloaded: i64,
    pub expected_length: Option<i64>,
    #[sea_orm(column_type = "Text")]
    pub status: String,
    pub retried_count: i32,
    #[sea_orm(column_type = "Text", nullable)]
    pub error_message: Option<String>,
    pub created_at: DateTime<FixedOffset>,
    pub updated_at: DateTime<FixedOffset>,
}

impl ActiveModelBehavior for ActiveModel {}
