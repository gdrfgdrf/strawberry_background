use std::sync::Arc;
use std::time::Duration;
use crate::db::models::preclude::{CookieKeysActiveModel, CookieKeysModel, CookiesActiveModel, CookiesModel};
use crate::domain::traits::http_traits::{DecryptionProvider, EncryptionProvider};

pub struct RuntimeConfig {
    pub http: Option<HttpConfig>,
    pub cookie: Option<CookieConfig>,
}

pub struct HttpConfig {
    pub connect_timeout: Duration,
    pub request_timeout: Duration,
    pub pool_idle_timeout: Duration,
    pub max_connections_per_host: usize,
    pub cookie_config: Option<CookieConfig>,
    pub encryption_provider: Option<Arc<dyn EncryptionProvider>>,
    pub decryption_provider: Option<Arc<dyn DecryptionProvider>>,
    pub all_proxy: Option<String>,
    pub host_proxy: Option<Vec<(String, String)>>,
    pub tls_danger_accept_invalid_hostnames: bool,
    pub tls_danger_accept_invalid_certs: bool
}

#[derive(Debug, Clone)]
pub struct CookieConfig {
    pub initial_cookies: Option<Vec<(CookieKeysActiveModel, CookiesActiveModel)>>
}

#[derive(Debug, Clone)]
pub struct FileCacheConfig {
    pub base_path: String,
    pub auto_save_interval: Duration,
    pub channels: Option<Vec<FileCacheChannelConfig>>
}

#[derive(Debug, Clone)]
pub struct FileCacheChannelConfig {
    pub name: String,
    pub extension: Option<String>,
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            http: None,
            cookie: None,
        }
    }
}
