use std::time::Instant;

/// Tracks cumulative bytes transferred and the resulting average throughput.
///
/// Uses `Instant` (monotonic) rather than `SystemTime` (wall clock, can jump
/// backwards on clock adjustments and would previously risk an underflow
/// panic when computing elapsed time).
pub struct SpeedAnalyzer {
    start_time: Option<Instant>,
    pub total: u64,
}

impl SpeedAnalyzer {
    pub fn new() -> Self {
        Self {
            start_time: None,
            total: 0,
        }
    }

    pub fn start(&mut self) {
        self.start_time = Some(Instant::now());
    }

    pub fn add(&mut self, delta: u64) {
        self.total = self.total.saturating_add(delta);
    }

    /// Average speed in bytes/second since `start` was called.
    ///
    /// Previously this truncated elapsed microseconds down to whole seconds
    /// via integer division, which meant `speed()` returned `total / 0`
    /// (i.e. `inf`/garbage) for the entire first second of any transfer.
    /// This now uses floating point seconds throughout.
    pub fn speed(&self) -> f32 {
        match self.start_time {
            Some(start) => {
                let elapsed_secs = start.elapsed().as_secs_f32();
                if elapsed_secs <= 0.0 {
                    0.0
                } else {
                    self.total as f32 / elapsed_secs
                }
            }
            None => 0.0,
        }
    }
}
