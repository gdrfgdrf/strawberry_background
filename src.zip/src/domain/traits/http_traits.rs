use crate::domain::models::http_models::{
    HttpClientError, HttpEndpoint, HttpResponse, HttpStreamResponse,
};
use async_trait::async_trait;
use futures_util::Stream;
use std::sync::Arc;

pub trait HttpClient {
    fn set_encryption_provider(&mut self, encryption_provider: Arc<dyn EncryptionProvider>);
    fn set_decryption_provider(&mut self, decryption_provider: Arc<dyn DecryptionProvider>);

    fn remove_encryption_provider(&mut self) -> Option<Arc<dyn EncryptionProvider>>;
    fn remove_decryption_provider(&mut self) -> Option<Arc<dyn DecryptionProvider>>;

    async fn execute(&self, endpoint: HttpEndpoint) -> Result<HttpResponse, HttpClientError>;
    async fn execute_stream(
        &self,
        endpoint: HttpEndpoint,
    ) -> Result<HttpStreamResponse, HttpClientError>;
}

pub trait EncryptionProvider: Send + Sync + 'static {
    fn encrypt(&self, bytes: &Vec<u8>) -> Result<Vec<u8>, HttpClientError>;
}

pub trait DecryptionProvider: Send + Sync + 'static {
    fn decrypt(&self, bytes: &Vec<u8>) -> Result<Vec<u8>, HttpClientError>;
}
