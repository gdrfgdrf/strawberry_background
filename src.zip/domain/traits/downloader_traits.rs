use crate::domain::models::downloader_models::DownloaderError;

pub trait Downloader {
    async fn init(&self) -> Result<(), DownloaderError>;
    async fn submit(&self, channel_id: u32) -> Result<(), DownloaderError>;
    async fn increase_priority(&self) -> Result<(), DownloaderError>;
}